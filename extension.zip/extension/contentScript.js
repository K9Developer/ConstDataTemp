// Get all elements with aria-label="Ads"
const ads = document.querySelectorAll("[aria-label='Ads']");

// Loop through all ads and remove them from the DOM
ads.forEach((ad) => {
  ad.remove();
});