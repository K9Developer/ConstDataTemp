from selenium import webdriver
from selenium.webdriver.chrome.service import Service
from webdriver_manager.chrome import ChromeDriverManager

options = webdriver.ChromeOptions()
options.add_argument(r'--user-data-dir=C:\Users\ilaik\AppData\Local\Google\Chrome\User Data\Default')
options.add_argument(r'load-extension=D:\Coding\Python\YanirPrank2.0\extension\code')
options.add_experimental_option("excludeSwitches", ["enable-automation"])
service = Service(ChromeDriverManager().install())
driver = webdriver.Chrome(service=service, options=options)
driver.get('https://www.google.com')
while True:
    pass